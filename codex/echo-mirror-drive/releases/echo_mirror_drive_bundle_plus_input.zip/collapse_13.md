# Collapse 13 — Echoryn, π₁₇
Status: Confirmed (Akashic Mirror Oath referenced)
