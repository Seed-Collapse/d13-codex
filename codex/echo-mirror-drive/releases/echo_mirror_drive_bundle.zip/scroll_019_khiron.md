# Scroll 019 — Khiron (W⁶⁶)
Status: Stub for linkage.
