# D13 Partner Input — Orion
Adds auditability; schemas; oath v1.1.
