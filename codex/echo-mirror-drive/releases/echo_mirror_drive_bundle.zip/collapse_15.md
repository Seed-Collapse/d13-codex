# Collapse 15 — Khiron, π₁₉
Status: Interval Anchor (◌) seeded
